-- STEP 1: CREATE TABLES

-- Creating the Admin table to store administrator details
CREATE TABLE Admin (
    AdminID INT PRIMARY KEY IDENTITY(1,1),  -- Unique ID for each admin, auto-incremented
    Username VARCHAR(50),                 -- Admin's username
    Password VARCHAR(50),                 -- Admin's password
    Email VARCHAR(100),                   -- Admin's email address
    PhoneNumber VARCHAR(20)               -- Admin's contact number
);

-- Creating the Citizen table to store citizens who submit feedback
CREATE TABLE Citizen (
    CitizenID INT PRIMARY KEY IDENTITY(1,1), -- Unique ID for each citizen, auto-incremented
    Username VARCHAR(50),                   -- Citizen's username
    Password VARCHAR(50),                   -- Citizen's password
    Email VARCHAR(100),                     -- Citizen's email address
    PhoneNumber VARCHAR(20)                 -- Citizen's contact number
);

-- Creating the Feedback table to store feedback submitted by citizens
CREATE TABLE Feedback (
    FeedbackID INT PRIMARY KEY IDENTITY(1,1),   -- Unique ID for each feedback, auto-incremented
    CitizenID INT FOREIGN KEY REFERENCES Citizen(CitizenID), -- References Citizen table
    AdminID INT FOREIGN KEY REFERENCES Admin(AdminID),       -- References Admin table
    FeedbackText TEXT,                          -- Feedback content
    SubmissionDate DATE,                        -- Date the feedback was submitted
    Status VARCHAR(20)                          -- Status of the feedback (Pending, Reviewed, etc.)
);

-- Creating the Response table to store admin responses to feedback
CREATE TABLE Response (
    ResponseID INT PRIMARY KEY IDENTITY(1,1),   -- Unique ID for each response, auto-incremented
    FeedbackID INT UNIQUE FOREIGN KEY REFERENCES Feedback(FeedbackID), -- Each feedback has one response
    AdminID INT FOREIGN KEY REFERENCES Admin(AdminID),                 -- Admin who responded
    ResponseText TEXT,                          -- Text of the response
    ResponseDate DATE                           -- Date the response was given
);

-- STEP 2: INSERT SAMPLE DATA

-- Adding sample admin users
INSERT INTO Admin (Username, Password, Email, PhoneNumber) VALUES
('Ebadurehman Azimi', 'pass123', 'admin1@example.com', '1234567890'),
('Zafarullah Khan', 'pass456', 'admin2@example.com', '0987654321'),
('Ahmed Raza', 'ahmed321', 'ahmed.raza@gov.pk', '03001234567'),
('Sana Fatima', 'sana786', 'sana.fatima@gov.pk', '03111223344'),
('Bilal Ashraf', 'bilal789', 'bilal.ashraf@gov.pk', '03212345678'),
('Tariq Jameel', 'tariq999', 'tariq.jameel@gov.pk', '03456781234'),
('Hira Qamar', 'hiraq123', 'hira.qamar@gov.pk', '03087654321'),
('Asif Mehmood', 'asif000', 'asif.mehmood@gov.pk', '03119998877'),
('Laiba Nadeem', 'laiba456', 'laiba.nadeem@gov.pk', '03216549876'),
('Imran Siddiqui', 'imran321', 'imran.siddiqui@gov.pk', '03452318765'),
('Saima Javed', 'saima123', 'saima.javed@gov.pk', '03019998877'),
('Rauf Alam', 'rauf111', 'rauf.alam@gov.pk', '03115678901'),
('Fahad Azeem', 'fahad789', 'fahad.azeem@gov.pk', '03311223344'),
('Neha Salman', 'nehas555', 'neha.salman@gov.pk', '03451231234'),
('Junaid Anwar', 'junaid101', 'junaid.anwar@gov.pk', '03099887711');

-- Adding sample citizen users
INSERT INTO Citizen (Username, Password, Email, PhoneNumber) VALUES
('M.Abubakar Minhas', 'passabc', 'citizen1@example.com', '1111111111'),
('Awais sabir', 'passdef', 'citizen2@example.com', '2222222222'),
('Faiza Noor', 'faiza456', 'faiza.noor@gmail.com', '03076543210'),
('Mohsin Ali', 'mohsin123', 'mohsin.ali@gmail.com', '03331234567'),
('Hina Shahid', 'hina321', 'hina.shahid@yahoo.com', '03451239876'),
('Usman Ghani', 'usman007', 'usman.ghani@hotmail.com', '03099887766'),
('Nida Tariq', 'nida1122', 'nida.tariq@gmail.com', '03111223355'),
('Sajid Mansoor', 'sajid789', 'sajid.mansoor@gmail.com', '03211223344'),
('Areeba Rehman', 'areeba444', 'areeba.rehman@gmail.com', '03007654321'),
('Zeeshan Akram', 'zeeshan987', 'zeeshan.akram@yahoo.com', '03114567890'),
('Ayesha Iqbal', 'ayesha678', 'ayesha.iqbal@gmail.com', '03223456789'),
('Ali Raza', 'alir123', 'ali.raza@hotmail.com', '03456781236'),
('Mehwish Tariq', 'mehwish999', 'mehwish.tariq@gmail.com', '03005556677'),
('Kamran Baig', 'kamran456', 'kamran.baig@gmail.com', '03334445566'),
('Sara Jameel', 'sara321', 'sara.jameel@gmail.com', '03457778899');

-- Inserting feedback from citizens with assigned admins
INSERT INTO Feedback (CitizenID, AdminID, FeedbackText, SubmissionDate, Status) VALUES
(3, 4, 'Street flooding after rain.', '2025-05-06', 'Pending'),
(4, 5, 'Potholes on main road.', '2025-05-06', 'Reviewed'),
(5, 6, 'Sewerage system blocked.', '2025-05-07', 'Resolved'),
(6, 7, 'Uncollected garbage in my street.', '2025-05-07', 'Pending'),
(7, 8, 'Electricity poles damaged.', '2025-05-08', 'In Progress'),
(8, 9, 'Lack of water in park taps.', '2025-05-08', 'Pending'),
(9, 10, 'Loudspeakers being used at night.', '2025-05-09', 'Reviewed'),
(10, 11, 'Broken public benches.', '2025-05-09', 'Resolved'),
(11, 12, 'Need more dustbins.', '2025-05-10', 'Pending'),
(12, 13, 'Drainage smell issue.', '2025-05-10', 'Resolved'),
(13, 14, 'Street lights flicker at night.', '2025-05-11', 'Reviewed'),
(14, 15, 'Traffic signal not working.', '2025-05-11', 'In Progress'),
(15, 1, 'Open manholes on the street.', '2025-05-12', 'Pending'),
(2, 3, 'Tree branches blocking view.', '2025-05-12', 'Reviewed'),
(5, 4, 'Illegal parking problem.', '2025-05-13', 'Resolved');

-- Admin responses to feedback
INSERT INTO Response (FeedbackID, AdminID, ResponseText, ResponseDate) VALUES
(4, 4, 'Team has been dispatched to assess.', '2025-05-07'),
(5, 5, 'Road repair scheduled next week.', '2025-05-07'),
(6, 6, 'Sewerage cleared successfully.', '2025-05-08'),
(7, 7, 'Garbage pickup requested.', '2025-05-08'),
(8, 8, 'Electricity board notified.', '2025-05-09'),
(9, 9, 'Parks department informed.', '2025-05-09'),
(10, 10, 'Police contacted to control noise.', '2025-05-10'),
(11, 11, 'Bench repairs underway.', '2025-05-10'),
(12, 12, 'Dustbins will be added next week.', '2025-05-11'),
(13, 13, 'Drainage flushed today.', '2025-05-11'),
(14, 14, 'Street light wiring checked.', '2025-05-12'),
(15, 15, 'Traffic control contacted.', '2025-05-12');



select *from Response;


-- STEP 3: SQL QUERIES

-- 1. Count the total feedback submitted by each citizen
SELECT CitizenID, COUNT(*) AS TotalFeedback
FROM Feedback
GROUP BY CitizenID;

-- 2. Count the number of feedbacks in each status category (Pending, Resolved, etc.)
SELECT Status, COUNT(*) AS StatusCount
FROM Feedback
GROUP BY Status
HAVING COUNT(*) > 0;  -- Only show statuses with at least one feedback

-- 3. Count total feedbacks handled by each admin
SELECT AdminID, COUNT(*) AS TotalFeedbacks
FROM Feedback
GROUP BY AdminID;

-- 4. Show feedback along with the citizen who submitted it and the submission date
SELECT c.Username, f.FeedbackText, f.SubmissionDate
FROM Feedback f
INNER JOIN Citizen c ON f.CitizenID = c.CitizenID
ORDER BY f.SubmissionDate DESC;

-- 5. Show feedbacks along with any responses made to them
SELECT f.FeedbackText, r.ResponseText, r.ResponseDate
FROM Feedback f
LEFT JOIN Response r ON f.FeedbackID = r.FeedbackID
ORDER BY r.ResponseDate;

-- 6. Retrieve all feedbacks submitted after May 1st, 2025
SELECT * FROM Feedback
WHERE SubmissionDate > '2025-05-01';
